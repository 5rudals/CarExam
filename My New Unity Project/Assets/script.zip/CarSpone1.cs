﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarSpone1 : MonoBehaviour {
    
    public Transform carspone1;
    public GameObject car;
    float delayTime = 2;



	void Update () {
        if (delayTime <= 0)
        {
            delayTime = 2;
            Instantiate(car, carspone1.position, carspone1.rotation);
        }
        delayTime -= Time.deltaTime;
	}
}