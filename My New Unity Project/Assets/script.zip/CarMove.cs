﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarMove : MonoBehaviour {

    int speed = 1;

    public void Start()
    {
        speed = Random.Range(1, 6);
    }
    /*int speed = 1;
    void Start()
    {
        MainScript mainScript = GameObject.Find("GameObject").GetComponent<MainScript>();
        speed = mainScript.speed;
    }*/

    void Update () {
        transform.Translate(Vector3.forward * speed * Time.deltaTime);

        if (this.transform.position.x > 16.0f || this.transform.position.x < -16.0f)
        Destroy(gameObject);
    }
}