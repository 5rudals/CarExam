﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainScript : MonoBehaviour {
    int speed = 1;

    void Start()
    {
        speed = Random.Range(1, 6);
        Debug.Log(speed);
    }
    void Update () {

	}
}
